package pal;

import java.io.IOException;

public class Main {
	public static void main(String[] args) throws IOException {
		FileReader reader = new FileReader();
		HighWayMap read = reader.read();
		Solver solver = new Solver();
		System.out.println(solver.solve(read));
	}
}
