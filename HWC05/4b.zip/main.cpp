#include <iostream>
#include <string>

using namespace std;

inline void readNumber(int *x) {
    register char c = getchar_unlocked();
    *x = 0;
    for (; (c < 48) || (c > 57); c = getchar_unlocked());
    for (; (c > 47) && (c < 58); c = getchar_unlocked()) {
        *x = (int) ((((*x) << 1) + ((*x) << 3)) + c - 48);
    }
}

void getChar(string &string)
{
    char c = '0';
    while((c = getchar())  && (c != -1 && c != '\n' && c != '\r'))
    {
        string += c;
    }
}

string word;
int abcLen;
int lenSubword;
int difference;

void read() {
    readNumber(& abcLen);
    readNumber(& lenSubword);
    readNumber(& difference);

    getChar(word);
}

int count(){
    int len = word.size();
    int global = 0;
    int lenDiff = lenSubword - difference;
    //printf("%d\n", len);
    for (int i = 0; i + lenSubword - 1 < len; ++i) {
        string sub = word.substr(i, lenSubword);
        for (int j = i + lenSubword; j + lenSubword - 1 < len; ++j) {
            string subsub = word.substr(j, lenSubword);
            int count = 0;
            for (int k = 0; k < lenSubword; ++k) {
                if (sub.at(k) != subsub.at(k)) {
                    count++;
                }
            }
            if (count == difference) {
                //cout << i << " " << sub << " " << subsub << "\n";
                global++;
            }
        }
        if(difference != 0) {
            // get lenSub - difference
            for (int j = i + lenSubword; j + lenDiff - 1 < len; ++j) {
                string subsub = word.substr(j, lenDiff);
                for (int k = 0; k + difference - 1 < lenSubword; ++k) {
                    string begin = sub.substr(0, k);
                    string end = sub.substr(k + difference, lenSubword - difference - k);
                    string news = begin + end;
                    //if(subsub == "hg" && sub == "ccchg")
                    if (news == subsub) {
                        global++;
                        //cout << i << " " << sub << " " << subsub << "\n";
                        break;
                    }
                }
            }
        }
    }
    //printf("\n\n");
    if(difference!=0) {
        for (int i = 0; i + lenDiff - 1 < len; ++i) {
            string sub = word.substr(i, lenDiff);
            for (int j = i + lenDiff; j + lenSubword - 1 < len; ++j) {
                string subsub = word.substr(j, lenSubword);
                for (int k = 0; k + difference - 1 < lenSubword; ++k) {
                    string begin = subsub.substr(0, k);
                    string end = subsub.substr(k + difference, lenSubword - difference - k);
                    string news = begin + end;
                    if (news == sub) {
                        global++;
                        //cout << i << " " << sub << " " << subsub << "\n";
                        break;
                    }
                }
            }
        }
    }
    //printf("\n");
    return global;
}

int main() {
    read();
    printf("%d", count());
    return 0;
}
