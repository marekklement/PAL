package pal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		int numberOfLines = Integer.parseInt(reader.readLine());
		List<double []> lines = new LinkedList<>();
		for (int i = 0; i < numberOfLines; i++){
			String s = reader.readLine();
			double [] line = Arrays.stream(s.split(" ")).mapToDouble(Double::parseDouble).toArray();
			lines.add(line);
		}
		//
		double len = 0;
		for (int i = 0; i < numberOfLines; i++){
			double[] node1 = lines.get(i);
			double[] node2;
			if(i != numberOfLines - 1) {
				node2 = lines.get(i+1);
			} else {
				node2 = lines.get(0);
			}
			if(node1[0] == node2[0]){
				len += absSum(node1[1], node2[1]);
			} else if(node1[1] == node2[1]){
				len += absSum(node1[0], node2[0]);
			} else {
				double a = absSum(node1[0], node2[0]);
				double b = absSum(node1[1],node2[1]);
				double a2 = a*a;
				double b2 = b*b;
				len += Math.sqrt(a2 + b2);
			}
		}
		int res = (int) Math.ceil(5*len);
		System.out.println(res);
	}

	private static double absSum(double a, double b){
		double res = a - b;
		if(res>=0){
			return res;
		} else {
			return b - a;
		}
	}
}
