package pal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		int numberOfLines = Integer.parseInt(reader.readLine());
		List<int []> lines = new LinkedList<>();
		for (int i = 0; i < numberOfLines; i++){
			String s = reader.readLine();
			int [] line = Arrays.stream(s.split(" ")).mapToInt(Integer::parseInt).toArray();
			lines.add(line);
		}
		//
		float len = 0;
		for (int i = 0; i < numberOfLines; i++){
			int[] node1 = lines.get(i);
			int[] node2;
			if(i != numberOfLines - 1) {
				node2 = lines.get(i+1);
			} else {
				node2 = lines.get(0);
			}
			if(node1[0] == node2[0]){
				len += Math.abs(node1[1] - node2[1]);
			} else if(node1[1] == node2[1]){
				len += Math.abs(node1[0] - node2[0]);
			} else {
				int a = Math.abs(node1[0] - node2[0]);
				int b = Math.abs(node1[1] - node2[1]);
				int a2 = a*a;
				int b2 = b*b;
				len += Math.sqrt(a2 + b2);
			}
		}
		int res = (int) Math.ceil(5*len);
		System.out.println(res);
	}
}
